package ru.avem.stand.tests.business

import ru.avem.stand.af
import ru.avem.stand.io.DevicePoller.DD2
import ru.avem.stand.io.DevicePoller.PAV41
import ru.avem.stand.io.DevicePoller.PC71
import ru.avem.stand.io.DevicePoller.UZ91
import ru.avem.stand.io.DevicePoller.PS81
import ru.avem.stand.testitem.TIManager
import ru.avem.stand.tests.KSPADTest
import ru.avem.stand.tests.model.Field
import ru.avem.stand.tests.model.TestRow
import ru.avem.stand.view.composables.table.*
import ru.avem.stand.view.composables.table.TableScheme.Companion.named

object Idling : KSPADTest(
    abbr = "ХХ",
    tag = "HH",
    name = "Определение тока и потерь холостого хода с измерением скорости вращения",
    tables(
        table1(
            columns(
                TestRow::c1 named "U, В",
                TestRow::c2 named "I, А",
                TestRow::c3 named "P, кВт",
                TestRow::c4 named "cos ф, о.е.",
                TestRow::c5 named "Время, с",
            )
        ),
        table2(
            columns(
                TestRow::c1 named "t раб., °C",
                TestRow::c2 named "t пол., °C",
                TestRow::c3 named "n, об/мин",
                TestRow::c4 named "V раб., мм/с",
                TestRow::c5 named "V пол., мм/с",
            )
        ),
        table3(
            columns(
                TestRow::c1 named "Состояние",
            )
        )
    )
) {
    private var I_RATIO = 300.0 / 5.0

    private val voltage = Field(380)
    private val testTime = Field(10, id = "Time1")

    private val testItemVoltageABMeas: Field = Field {
        testItemVoltageMeas.value = (it.d + testItemVoltageBCMeas.d + testItemVoltageCAMeas.d) / 3.0
    } pollBy with(PAV41) { this to model.U_AB_REGISTER }
    private val testItemVoltageBCMeas: Field = Field {
        testItemVoltageMeas.value = (testItemVoltageABMeas.d + it.d + testItemVoltageCAMeas.d) / 3.0
    } pollBy with(PAV41) { this to model.U_BC_REGISTER }
    private val testItemVoltageCAMeas: Field = Field {
        testItemVoltageMeas.value = (testItemVoltageABMeas.d + testItemVoltageBCMeas.d + it.d) / 3.0
    } pollBy with(PAV41) { this to model.U_CA_REGISTER }
    private val testItemVoltageMeas: Field = Field(id = "U") bindTo table1r1.c1

    private val testItemCurrentAMeas: Field = Field {
        testItemCurrentMeas.value = (it.d + testItemCurrentBMeas.d + testItemCurrentCMeas.d) / 3.0 * I_RATIO
    } pollBy with(PAV41) { this to model.I_A_REGISTER }
    private val testItemCurrentBMeas: Field = Field {
        testItemCurrentMeas.value = (testItemCurrentAMeas.d + it.d + testItemCurrentCMeas.d) / 3.0 * I_RATIO
    } pollBy with(PAV41) { this to model.I_B_REGISTER }
    private val testItemCurrentCMeas: Field = Field {
        testItemCurrentMeas.value = (testItemCurrentAMeas.d + testItemCurrentBMeas.d + it.d) / 3.0 * I_RATIO
    } pollBy with(PAV41) { this to model.I_C_REGISTER }
    private val testItemCurrentMeas: Field = Field(id = "I") bindTo table1r1.c2

    private val powerRaw = Field(abs = true) { power.value = it.d * I_RATIO } pollBy with(PAV41) { this to model.P_REGISTER }
    private val power = Field(id = "P1") bindTo table1r1.c3
    private val cos = Field(id = "Cos") pollBy with(PAV41) { this to model.COS_REGISTER } bindTo table1r1.c4

    private val timePassed = Field(id = "Time2") bindTo table1r1.c5

    private val tempShaftside: Field = Field(id = "Temp1") pollBy with(PS81) { this to model.T_1 } bindTo table2r1.c1
    private val tempFanside: Field = Field(id = "Temp2") pollBy with(PS81) { this to model.T_2 } bindTo table2r1.c2

    private val rpm: Field = Field(id = "Speed") pollBy with(PC71) { this to model.RPM } bindTo table2r1.c3

    private val vibrationShaftside = Field(abs = true, id = "Vibro1") pollBy with(DD2) { this to model.AI_01_F } bindTo table2r1.c4
    private val vibrationFanside = Field(abs = true, id = "Vibro2") pollBy with(DD2) { this to model.AI_02_F } bindTo table2r1.c5


    private val out1UFI = Field(init = 0.0, min = 0.0, max = 400.0) {
        UZ91.setVoltage(it.d)
        UZ91.setObjectFCur(it.d / 7.6)
    }

    override val stateCell = table3r1.c1

    override val fields = listOf(
        testTime,

        testItemVoltageABMeas,
        testItemVoltageBCMeas,
        testItemVoltageCAMeas,
        testItemVoltageMeas,

        testItemCurrentAMeas,
        testItemCurrentBMeas,
        testItemCurrentCMeas,
        testItemCurrentMeas,

        powerRaw,
        power,
        cos,
        timePassed,

        tempShaftside,
        tempFanside,

        rpm,

        vibrationShaftside,
        vibrationFanside,

        out1UFI,
    )

    override val checkedDevices = listOf(PAV41, PS81, PC71)

    override val alertMessages = listOf("Подключите провода U, V, W к ОИ. Установите датчики")

    init {
        define(
            initVariables = {
                I_RATIO = 300.0 / 5.0
                testTime.value = TIManager.testItem.idleTestTime
            },
            assemblyCircuit = {
                DD2.onIdling()
                loadUZ91()
            },
            process = {
                if (isRunning) {
                    setVoltageByUZ91()
                    selectCurrentStage({ testItemCurrentMeas.d }) { I_RATIO = it }

                    if (isRunning) state = "Ожидание $testTime s..."
                    wait(testTime.value) {
                        if (testItemCurrentMeas.d >= 160) cause = "Сработала токовая защита"
                        timePassed.value = it
                        state = "Осталось ${(testTime.d - it).af()} с"
                    }
                }
            },
            finish = {
                UZ91.offFreewheeling(out1UFI)
            }
        )
    }

    private fun setVoltageByUZ91() {
        state = "Инициализация ЧП"
        if (isRunning) UZ91.setObjectParamsRun()
        if (isRunning) UZ91.setVoltage(0.0)
        if (isRunning) UZ91.setObjectFCur(0.0)
        if (isRunning) UZ91.startObject()
        wait(3)

        state = "Подъём напряжения до ${voltage.d.af()} В (контроль PAV41) по UZ91"
        regulation(
            out1UFI,
            voltage.d,
            deltaMin = 1,
            deltaMax = 3,
            influenceStep = 1,
            waitSec = .05
        ) { testItemVoltageMeas.d }

        if (isRunning) state = "Напряжение установлено: $testItemVoltageMeas В"
    }
}
