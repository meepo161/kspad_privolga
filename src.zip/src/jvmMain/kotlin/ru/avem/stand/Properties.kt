package ru.avem.stand

const val title = "КСПАД Приволга 2023"
const val width = 1600
const val height = 900
