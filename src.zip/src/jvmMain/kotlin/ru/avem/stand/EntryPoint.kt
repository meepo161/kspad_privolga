package ru.avem.stand

import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.material.MaterialTheme
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowPlacement
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import cafe.adriel.voyager.navigator.Navigator
import cafe.adriel.voyager.transitions.SlideTransition
import ru.avem.stand.view.screens.InitializationScreen
import ru.avem.stand.view.theme.colors
import ru.avem.stand.view.theme.typography

@ExperimentalAnimationApi
fun main() = application {
    Window(
        onCloseRequest = ::exit,
        state = rememberWindowState(size = DpSize(width.dp, height.dp), placement = WindowPlacement.Maximized),
        title = title,
        undecorated = true,
        resizable = false,
    ) { MaterialTheme(colors, typography) { Navigator(InitializationScreen()) { SlideTransition(it) } } }
}
