package ru.avem.stand.view.composables

import androidx.compose.runtime.*
import ru.avem.stand.af
import ru.avem.stand.testitem.TestItemLocal
import ru.avem.stand.view.screens.main.MainViewModel

enum class MotorType(val text: String) {
    A("АД"),
    AWR("АД с ФР"),
    ATS("АД с термодатчиками"),
    AWRTS("АД с ФР и термодатчиками");

    override fun toString() = text

    companion object {
        val all = listOf(A, AWR, ATS, AWRTS)
        val withSensors = listOf(ATS, AWRTS)
        val wrs = listOf(AWR, AWRTS)

        fun valueOfText(text: String) = all.first { it.text == text }
    }
}

enum class SchemeType(private val glyph: String) {
    TRIANGLE("△"),
    STAR("Y");

    override fun toString() = glyph

    companion object {
        val all = listOf(TRIANGLE.glyph, STAR.glyph)
    }
}

@Composable
fun AddTestItemDialog(
    ti: TestItemLocal?,
    isVisible: MutableState<Boolean>,
    vm: MainViewModel,
    onAdd: (TestItemLocal) -> Unit
) {
    val nominalParameters =
        DialogRowData(
            name = "Номинальные параметры объекта испытания",
            type = DialogRowType.LABEL,
        )
    val motor by remember {
        mutableStateOf(
            DialogRowData(
                name = "Тип",
                type = DialogRowType.COMBO,
                variableField = MotorType.all.map { it.text },
                field = mutableStateOf(ti?.motor ?: "")
            )
        )
    }
    val name by remember {
        mutableStateOf(
            DialogRowData(
                name = "Тип",
                field = mutableStateOf(ti?.name ?: "")
            )
        )
    }
    val nominalPower by remember {
        mutableStateOf(
            DialogRowData(
                name = "Мощность ОИ, кВт (0 - 100)",
                field = mutableStateOf(ti?.nominalPower?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 0.0,
                maxValue = 100.0
            )
        )
    }
    val nominalVoltage by remember {
        mutableStateOf(
            DialogRowData(
                name = "Напряжение ОИ, В",
                field = mutableStateOf(ti?.nominalVoltage?.af() ?: "380"),
                type = DialogRowType.NUMBERIC,
                minValue = 380.0,
                maxValue = 380.0
            )
        )
    }
    val frequency by remember {
        mutableStateOf(
            DialogRowData(
                name = "Частота, Гц",
                field = mutableStateOf(ti?.frequency?.af() ?: "50"),
                type = DialogRowType.NUMBERIC,
                minValue = 50.0,
                maxValue = 50.0
            )
        )
    }
    val nominalCurrent by remember {
        mutableStateOf(
            DialogRowData(
                name = "Ток ОИ, А (0 - 250)",
                field = mutableStateOf(ti?.nominalCurrent?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 0.0,
                maxValue = 250.0
            )
        )
    }
    val nominalN by remember {
        mutableStateOf(
            DialogRowData(
                name = "Скорость вращения, об/мин (0 - 3000)",
                field = mutableStateOf(ti?.nominalN?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 0.0,
                maxValue = 3000.0
            )
        )
    }
    val nominalCos by remember {
        mutableStateOf(
            DialogRowData(
                name = "Коэффициент мощности, о.е. (0 - 1)",
                field = mutableStateOf(ti?.nominalCos?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 0.0,
                maxValue = 1.0
            )
        )
    }

    val scheme by remember {
        mutableStateOf(
            DialogRowData(
                name = "Схема статора",
                type = DialogRowType.COMBO,
                variableField = SchemeType.all,
                field = mutableStateOf(ti?.scheme ?: "")
            )
        )
    }

    val meggerParameters =
        DialogRowData(
            name = "Данные для проведения \"Измерение сопротивления изоляции обмотки статора\"",
            type = DialogRowType.LABEL,
        )
    val meggerVoltage by remember {
        mutableStateOf(
            DialogRowData(
                name = "Напряжение мегаомметра, В (500 - 2500)",
                field = mutableStateOf(ti?.meggerVoltage?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 500.0,
                maxValue = 2500.0
            )
        )
    }

    val hvParameters =
        DialogRowData(
            name = "Данные для проведения \"Испытание изоляции обмотки статора\" ",
            type = DialogRowType.LABEL,
        )
    val hvVoltage by remember {
        mutableStateOf(
            DialogRowData(
                name = "Напряжение высоковольтное, В (1000 - 3000)",
                field = mutableStateOf(ti?.hvVoltage?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 1000.0,
                maxValue = 3000.0
            )
        )
    }
    val hvCurrent by remember {
        mutableStateOf(
            DialogRowData(
                name = "Ток утечки, мА (20 - 100)",
                field = mutableStateOf(ti?.hvCurrent?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 20.0,
                maxValue = 100.0
            )
        )
    }
    val hvTestTime by remember {
        mutableStateOf(
            DialogRowData(
                name = "Время выдержки напряжения, сек (0 - 90)",
                field = mutableStateOf(ti?.hvTestTime?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 0.0,
                maxValue = 90.0,
            )
        )
    }

    val idleParameters =
        DialogRowData(
            name = "Данные для проведения \"Определение тока и потерь холостого хода\" ",
            type = DialogRowType.LABEL,
        )
    val idleTestTime by remember {
        mutableStateOf(
            DialogRowData(
                name = "Время выдержки напряжения, сек (0 - 600)",
                field = mutableStateOf(ti?.idleTestTime?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 0.0,
                maxValue = 600.0,
            )
        )
    }
    val runoutParameters =
        DialogRowData(
            name = "Данные для проведения \"Обкатка на холостом ходу\" ",
            type = DialogRowType.LABEL,
        )
    val runoutTestTime by remember {
        mutableStateOf(
            DialogRowData(
                name = "Время выдержки напряжения, сек (0 - 3600)",
                field = mutableStateOf(ti?.runoutTestTime?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 0.0,
                maxValue = 3600.0,
            )
        )
    }

    val meggerSParameters =
        DialogRowData(
            name = "Данные для проведения \"Измерение сопротивления изоляции термодатчика\"",
            type = DialogRowType.LABEL,
        )
    val meggerSVoltage by remember {
        mutableStateOf(
            DialogRowData(
                name = "Напряжение мегаомметра, В (500 - 2500)",
                field = mutableStateOf(ti?.meggerSVoltage?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 500.0,
                maxValue = 2500.0
            )
        )
    }

    val hvSParameters =
        DialogRowData(
            name = "Данные для проведения \"Испытание изоляции термодатчика\" ",
            type = DialogRowType.LABEL,
        )
    val hvSVoltage by remember {
        mutableStateOf(
            DialogRowData(
                name = "Напряжение высоковольтное, В (1000 - 3000)",
                field = mutableStateOf(ti?.hvSVoltage?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 1000.0,
                maxValue = 3000.0
            )
        )
    }
    val hvSCurrent by remember {
        mutableStateOf(
            DialogRowData(
                name = "Ток утечки, мА (20 - 100)",
                field = mutableStateOf(ti?.hvSCurrent?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 20.0,
                maxValue = 100.0
            )
        )
    }
    val hvSTestTime by remember {
        mutableStateOf(
            DialogRowData(
                name = "Время выдержки напряжения, сек (0 - 90)",
                field = mutableStateOf(ti?.hvSTestTime?.af() ?: ""),
                type = DialogRowType.NUMBERIC,
                minValue = 0.0,
                maxValue = 90.0,
            )
        )
    }

    val fields = listOf(
        nominalParameters,
        motor,
        name,
        nominalPower,
        nominalVoltage,
        nominalCurrent,
        nominalN,
        nominalCos,
        scheme,
        frequency,

        hvParameters,
        hvVoltage,
        hvCurrent,
        hvTestTime,

        meggerParameters,
        meggerVoltage,

        idleParameters,
        idleTestTime,

        runoutParameters,
        runoutTestTime,

        meggerSParameters,
        meggerSVoltage,

        hvSParameters,
        hvSVoltage,
        hvSCurrent,
        hvSTestTime,
    )

    fun checkFields(): Boolean {
        var isCorrect = true
        fields.forEach {
            if (it.type == DialogRowType.NUMBERIC) {
                it.errorState.value = it.field.value.isEmpty()
                        || it.field.value.toDoubleOrNull() == null
                        || it.field.value.toDouble() < it.minValue
                        || it.field.value.toDouble() > it.maxValue
            } else if(it.type == DialogRowType.COMBO || it.type == DialogRowType.TEXT) {
                it.errorState.value = it.field.value.isEmpty()
            }
            isCorrect = isCorrect && !it.errorState.value
        }
        return isCorrect
    }

    RowsAlertDialog(
        title = "Заполните поля:",
        rows = fields,
        isDialogVisible = isVisible,
        buttonText = if (ti == null) "Создать" else "Изменить",
        checkCreateProjectErrors = ::checkFields
    ) {
        if (checkFields()) {
            onAdd(
                TestItemLocal(
                    0,
                    name.field.value,
                    nominalPower.field.value.toDouble(),
                    nominalVoltage.field.value.toDouble(),
                    nominalCurrent.field.value.toDouble(),
                    nominalN.field.value.toDouble(),
                    nominalCos.field.value.toDouble(),
                    motor.field.value,
                    scheme.field.value,
                    frequency.field.value.toDouble(),
                    hvVoltage.field.value.toDouble(),
                    hvCurrent.field.value.toDouble(),
                    meggerVoltage.field.value.toDouble(),
                    idleTestTime.field.value.toDouble(),
                    runoutTestTime.field.value.toDouble(),
                    hvTestTime.field.value.toDouble(),
                    meggerSVoltage.field.value.toDouble(),
                    hvSVoltage.field.value.toDouble(),
                    hvSCurrent.field.value.toDouble(),
                    hvSTestTime.field.value.toDouble(),
                )
            )
        } else {
            vm.isCheckFieldsDialogVisible.value = true

        }
    }
    checkFields()
}
