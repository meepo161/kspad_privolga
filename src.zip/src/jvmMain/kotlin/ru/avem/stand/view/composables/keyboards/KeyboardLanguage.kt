package ru.avem.stand.view.composables.keyboards

sealed class KeyboardLanguage {
    object RU : KeyboardLanguage()
    object EN : KeyboardLanguage()
}
