package ru.avem.stand.view

import javax.swing.JOptionPane.*
import javax.swing.UIManager

fun showYesNoDialog(yesCallback: () -> Unit = {}, noCallback: () -> Unit = {}) {
    UIManager.put("OptionPane.yesButtonText", "Да")
    UIManager.put("OptionPane.noButtonText", "Нет")
    val result = showConfirmDialog(null, "Вы действительно хотите выйти?", "Внимание!", YES_NO_OPTION)

    if (result == YES_OPTION) {
        yesCallback()
    } else if (result == NO_OPTION) {
        noCallback()
    }
}
